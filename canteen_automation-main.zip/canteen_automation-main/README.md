# canteen_automation
a web project by 3 Edinburgh Napier students.
Intended for food ordering from Canteen.
